package com.in.pi;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.in.bean.BillBean;
import com.in.service.BillService;
import com.in.service.IBillService;

/**
 * Servlet implementation class CalculateBill
 */
@WebServlet("/CalculateBill")
public class CalculateBill extends HttpServlet {
	private static final long serialVersionUID = 1L;
    BillBean bean = new BillBean();
    BillBean bean1 = new BillBean();
    IBillService service = new BillService();
	double fixedCharge = 100.0;
    double unitsConsumed = 0;
    double netAmount = 0.00;
    public CalculateBill() {
        super();
        // TODO Auto-generated constructor stub
    }
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		ServletContext context = request.getServletContext();
		String ConsumerNum = request.getParameter("number");
		
		double lastMonth = Double.parseDouble(request.getParameter("lastMonth"));
		double currentMonth = Double.parseDouble(request.getParameter("currentMonth"));
		
		
				
		if(lastMonth < currentMonth)
				unitsConsumed = Math.abs(lastMonth - currentMonth);
		else
			out.println("Readings error");
		netAmount = unitsConsumed * 1.15 + fixedCharge;
		int consNum = Integer.parseInt(ConsumerNum);
		if(service.ValidateConsNumber(consNum) == 0)
		{
			out.println("Invalid Consumer Number");
		}
		else{
			bean.setConsumerNum(consNum);
			bean.setCurrentMonth(currentMonth);
			bean.setUnitsCons(unitsConsumed);
			bean.setNetAmount(netAmount);
			
			service.storeBillData(bean);
		
			out.println("Welcome  "+ context.getAttribute("ID"));
			out.println("<html><h3>"+"Electricity Bill for Consumer Number : " + bean.getConsumerNum()+"is : </h3></html>");
			out.println("<html><h2>Units Consumed :: "+bean.getUnitsCons()+"</h2></html>");
			out.println("<html><h2>Net Amount :: "+bean.getNetAmount()+"</h2></html>");
		}
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
