package com.in.service;

import com.in.bean.BillBean;
import com.in.dao.BillDAO;
import com.in.dao.IBillDAO;

public class BillService implements IBillService{

	@Override
	public void storeBillData(BillBean bean) {
		IBillDAO daoBean = new BillDAO();
		daoBean.storeBillData(bean);
		// TODO Auto-generated method stub
		
	}

	@Override
	public int ValidateConsNumber(int number) {
		IBillDAO daoBean = new BillDAO();
		
		return daoBean.ValidateConsNumber(number);
	}

}
