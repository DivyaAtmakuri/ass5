package com.in.service;

import com.in.bean.BillBean;

public interface IBillService {
	public abstract void storeBillData(BillBean bean);
	public abstract int ValidateConsNumber(int number);
}
