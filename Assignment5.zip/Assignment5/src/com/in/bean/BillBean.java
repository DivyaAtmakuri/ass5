package com.in.bean;

import java.sql.Date;

public class BillBean {
	private double billIid;
	private int consumerNum;
	private double currentMonth;
	private double unitsCons;
	private double netAmount;
	private Date billDate;
	public double getBillIid() {
		return billIid;
	}
	public void setBillIid(double billIid) {
		this.billIid = billIid;
	}
	public int getConsumerNum() {
		return consumerNum;
	}
	public void setConsumerNum(int consNum) {
		this.consumerNum = consNum;
	}
	public double getCurrentMonth() {
		return currentMonth;
	}
	public void setCurrentMonth(double currentMonth) {
		this.currentMonth = currentMonth;
	}
	public double getUnitsCons() {
		return unitsCons;
	}
	public void setUnitsCons(double unitsCons) {
		this.unitsCons = unitsCons;
	}
	public double getNetAmount() {
		return netAmount;
	}
	public void setNetAmount(double netAmount) {
		this.netAmount = netAmount;
	}
	public Date getBillDate() {
		return billDate;
	}
	public void setBillDate(Date billDate) {
		this.billDate = billDate;
	}
	
	
}
