package com.in.dao;

import com.in.bean.BillBean;

public interface IBillDAO {
	public abstract void storeBillData(BillBean bean);
	public abstract int ValidateConsNumber(int number);
	
}
