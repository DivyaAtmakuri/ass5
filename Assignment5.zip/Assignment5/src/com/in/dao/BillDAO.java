package com.in.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDate;

import javax.naming.InitialContext;
import javax.sql.DataSource;

import com.in.bean.BillBean;

public class BillDAO implements IBillDAO{
	Connection con;
	LocalDate date = LocalDate.now();
	@Override
	public void storeBillData(BillBean bean) {
		try {
			InitialContext ic = new InitialContext();
			DataSource ds = (DataSource) ic.lookup("java:/OracleDS");
			con = ds.getConnection();
			
			PreparedStatement ps = con.prepareStatement("INSERT INTO BILLDETAILS VALUES(SEQ_BILL_NUM.NEXTVAL,?,?,?,?,SYSDATE)");
			
			ps.setInt(1, bean.getConsumerNum());
			ps.setDouble(2, bean.getCurrentMonth());
			ps.setDouble(3, bean.getUnitsCons());
			ps.setDouble(4, bean.getNetAmount());
			
			int result = ps.executeUpdate();
			if(result == 1)
				System.out.println("Data inserted");
			else
				System.out.println("Data not inserted");
			con.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Override
	public int ValidateConsNumber(int number) {
		int count = 0;
		try {
			InitialContext ic = new InitialContext();
			DataSource ds = (DataSource) ic.lookup("java:/OracleDS");
			con = ds.getConnection();
			PreparedStatement ps = con.prepareStatement("select count(*) from CONSUMERS where CONSUMER_NUM = "+number);
			ResultSet rs  = ps.executeQuery();
			rs.next();
			System.out.println(rs.getInt(1));
			if(rs.getInt(1) < 1)
			{
				count = 0;
			}
			else{
				count = 1;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return count;
	}

	

}
